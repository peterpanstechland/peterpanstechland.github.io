"""Behavior checks for portable, evidence-backed explorer artifacts.

Run with ``python -m unittest discover -s skills/aws-interactive-architecture/scripts
-p 'test_*.py' -v`` from the repository root. The real-model check is skipped when
this package is installed without the Courtside repository.
"""
import copy
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path


SCRIPT = Path(__file__).with_name('build_explorer.py')
PACKAGE = SCRIPT.parents[1]
REPO_ROOT = PACKAGE.parents[1]
spec = importlib.util.spec_from_file_location('architecture_builder_under_test', SCRIPT)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


class Document(HTMLParser):
    """Inspect browser-visible element boundaries, not serialization details."""

    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.scripts = []
        self.start_tags = []
        self.title = ''
        self._script = None
        self._in_title = False
        self.feed(source)
        self.close()

    def handle_starttag(self, tag, attrs):
        self.start_tags.append(tag)
        if tag == 'script':
            self._script = {'attrs': dict(attrs), 'text': ''}
            self.scripts.append(self._script)
        elif tag == 'title':
            self._in_title = True

    def handle_data(self, data):
        if self._script is not None:
            self._script['text'] += data
        elif self._in_title:
            self.title += data

    def handle_endtag(self, tag):
        if tag == 'script':
            self._script = None
        elif tag == 'title':
            self._in_title = False

    @property
    def model(self):
        matches = [s for s in self.scripts if s['attrs'].get('id') == 'architecture-model']
        if len(matches) != 1:
            raise AssertionError('Expected exactly one embedded model')
        return json.loads(matches[0]['text'])


class BuildExplorerTests(unittest.TestCase):
    def setUp(self):
        self.model = json.loads((PACKAGE / 'assets/starter/example.json').read_text(encoding='utf-8'))

    def evidence_model(self, path='src/handler.py', line=2):
        model = copy.deepcopy(self.model)
        model['nodes'][0].update(status='implemented', evidence=[{
            'path': path, 'line': line, 'claim': 'The handler validates an upload request.',
        }])
        return model

    def make_repo(self, directory):
        root = Path(directory) / 'repo'
        (root / 'src').mkdir(parents=True)
        (root / 'src/handler.py').write_text('# Upload boundary\nvalidate_request()\n', encoding='utf-8')
        return root

    def test_example_builds_self_contained_html_without_mutating_input(self):
        original = copy.deepcopy(self.model)
        builder.validate(self.model)
        document = Document(builder.build(self.model))
        self.assertEqual(document.title, self.model['title'])
        self.assertEqual(document.model['folders'], self.model['folders'])
        self.assertEqual(self.model, original)
        self.assertEqual(len(document.scripts), 2)
        self.assertTrue(all('src' not in script['attrs'] for script in document.scripts))
        self.assertNotIn('link', document.start_tags, 'The file must not require a remote stylesheet')
        self.assertTrue(document.model['nodes'][1]['iconData'].startswith('data:image/svg+xml;base64,'))

    def test_courtside_models_validate_their_actual_repository_references(self):
        paths = [REPO_ROOT / 'docs/sharing' / f'courtside-architecture.{locale}.json' for locale in ('en', 'zh')]
        if not all(path.is_file() for path in paths):
            self.skipTest('Courtside source models are not part of this installed package')
        models = []
        for path in paths:
            with self.subTest(locale=path.name):
                model = json.loads(path.read_text(encoding='utf-8'))
                builder.validate(model, REPO_ROOT)
                self.assertRegex(model['revision'], r'^[0-9a-f]{40}$')
                self.assertEqual(Document(builder.build(model)).model['locale'], model['locale'])
                models.append(model)
        self.assertEqual(models[0]['revision'], models[1]['revision'])
        self.assertEqual({node['id'] for node in models[0]['nodes']}, {node['id'] for node in models[1]['nodes']})

    def test_edges_cannot_target_missing_or_unplaced_nodes_or_themselves(self):
        orphan = copy.deepcopy(self.model['nodes'][0])
        orphan['id'] = 'unplaced'
        self.model['nodes'].append(orphan)
        for source, target in [('missing', 'api'), ('client', 'unplaced'), ('client', 'client')]:
            with self.subTest(source=source, target=target):
                model = copy.deepcopy(self.model)
                model['folders'][0]['edges'][0].update({'from': source, 'to': target})
                with self.assertRaisesRegex(ValueError, 'endpoint|self-loop'):
                    builder.validate(model)

    def test_touching_cards_are_valid_but_even_small_overlaps_are_rejected(self):
        client, api = self.model['folders'][0]['nodes'][:2]
        api['x'] = client['x'] + client['w']
        builder.validate(self.model)
        api['x'] -= 0.25
        with self.assertRaisesRegex(ValueError, 'Overlapping placements'):
            builder.validate(self.model)

    def test_evidence_rejects_path_traversal_and_absolute_path_forms(self):
        unsafe = ['../outside.py', 'src/../../outside.py', '/etc/passwd',
                  'C:/outside.py', r'src\handler.py', '.hidden/file.py']
        for path in unsafe:
            with self.subTest(path=path):
                with self.assertRaisesRegex(ValueError, 'safe repository-relative paths'):
                    builder.validate(self.evidence_model(path))

    def test_repo_root_checks_file_presence_and_inclusive_line_bounds(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.make_repo(directory)
            builder.validate(self.evidence_model(line=2), root)
            with self.assertRaisesRegex(ValueError, 'line out of range'):
                builder.validate(self.evidence_model(line=3), root)
            with self.assertRaisesRegex(ValueError, 'Missing or escaping evidence file'):
                builder.validate(self.evidence_model('src/missing.py'), root)

    def test_repo_root_rejects_an_in_tree_symlink_to_an_outside_file(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.make_repo(directory)
            outside = Path(directory) / 'outside.py'
            outside.write_text('# outside\nsecret = True\n', encoding='utf-8')
            try:
                (root / 'src/link.py').symlink_to(outside)
            except (OSError, NotImplementedError) as error:
                self.skipTest(f'Symlinks are unavailable: {error}')
            with self.assertRaisesRegex(ValueError, 'Missing or escaping evidence file'):
                builder.validate(self.evidence_model('src/link.py'), root)

    def test_repository_links_reject_non_https_credentials_and_url_suffixes(self):
        invalid = ['http://example.com/team/repo', 'javascript:alert(1)',
                   'https://user:password@example.com/repo',
                   'https://example.com/repo?token=private', 'https://example.com/repo#fragment']
        for url in invalid:
            with self.subTest(url=url):
                model = copy.deepcopy(self.model)
                model.update(repoUrl=url, revision='a' * 40)
                with self.assertRaisesRegex(ValueError, 'public HTTPS repository URL'):
                    builder.validate(model)

    def test_tampered_used_icon_fails_hash_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            icons = Path(directory) / 'icons'
            shutil.copytree(PACKAGE / 'assets/icons', icons)
            used_icon = icons / (self.model['nodes'][1]['icon'] + '.svg')
            used_icon.write_bytes(used_icon.read_bytes() + b'\n<!-- changed -->\n')
            with self.assertRaisesRegex(ValueError, 'Icon hash mismatch'):
                builder.build(self.model, icons)

    def test_supplied_icon_data_cannot_override_verified_package_assets(self):
        untrusted = 'data:image/svg+xml,<svg onload="alert(1)"/>'
        self.model['nodes'][0]['iconData'] = untrusted
        self.model['nodes'][1]['iconData'] = untrusted
        rendered = Document(builder.build(self.model)).model
        self.assertNotIn('iconData', rendered['nodes'][0])
        self.assertTrue(rendered['nodes'][1]['iconData'].startswith('data:image/svg+xml;base64,'))
        self.assertNotEqual(rendered['nodes'][1]['iconData'], untrusted)
        self.assertEqual(self.model['nodes'][1]['iconData'], untrusted)

    def test_model_text_cannot_break_out_of_json_or_title_elements(self):
        payload = '</title></ScRiPt><script>alert("injected")</script><img src=x onerror=alert(2)>&\u2028\u2029'
        self.model['title'] = payload
        self.model['nodes'][0]['summary'] = payload
        builder.validate(self.model)
        document = Document(builder.build(self.model))
        self.assertEqual(document.title, payload)
        self.assertEqual(document.model['title'], payload)
        self.assertEqual(document.model['nodes'][0]['summary'], payload)
        self.assertEqual(len(document.scripts), 2, 'Model text must not create an executable script')
        self.assertNotIn('img', document.start_tags)

    def test_template_marker_text_is_preserved_as_literal_model_content(self):
        markers = '__MODEL__ __TITLE__ __STYLES__ __GEOMETRY__ __EXPLORER__ __LOCALE__'
        self.model['title'] = markers
        self.model['nodes'][0]['summary'] = markers
        document = Document(builder.build(self.model))
        self.assertEqual(document.title, markers)
        self.assertEqual(document.model['title'], markers)
        self.assertEqual(document.model['nodes'][0]['summary'], markers)
        self.assertEqual(len(document.scripts), 2)

    def test_malformed_nested_objects_produce_cli_errors_without_tracebacks(self):
        cases = {
            'folder': 'folder must be an object',
            'placement': 'placement must be an object',
            'edge': 'edge must be an object',
            'step': 'step must be an object',
            'boundaries': 'boundaries must be an array',
        }
        with tempfile.TemporaryDirectory() as directory:
            for kind, message in cases.items():
                with self.subTest(kind=kind):
                    model = copy.deepcopy(self.model)
                    folder = model['folders'][0]
                    if kind == 'folder':
                        model['folders'][0] = None
                    elif kind == 'boundaries':
                        folder['boundaries'] = {}
                    else:
                        field = {'placement': 'nodes', 'edge': 'edges', 'step': 'steps'}[kind]
                        folder[field][0] = None
                    model_path = Path(directory) / f'{kind}.json'
                    model_path.write_text(json.dumps(model), encoding='utf-8')
                    output = Path(directory) / f'{kind}.html'
                    result = subprocess.run([sys.executable, str(SCRIPT), '--model', str(model_path),
                                             '--output', str(output)], text=True, capture_output=True, check=False)
                    self.assertEqual(result.returncode, 2, result.stderr)
                    self.assertIn(message, result.stderr)
                    self.assertNotIn('Traceback', result.stderr)
                    self.assertFalse(output.exists())

    def test_cli_uses_repo_root_and_does_not_publish_an_invalid_artifact(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.make_repo(directory)
            model_path = Path(directory) / 'model.json'
            model_path.write_text(json.dumps(self.evidence_model()), encoding='utf-8')
            good_output = Path(directory) / 'good/architecture.html'
            result = subprocess.run([sys.executable, str(SCRIPT), '--model', str(model_path),
                                     '--output', str(good_output), '--repo-root', str(root)],
                                    text=True, capture_output=True, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(Document(good_output.read_text(encoding='utf-8')).model['title'], self.model['title'])
            bad_output = Path(directory) / 'bad/architecture.html'
            result = subprocess.run([sys.executable, str(SCRIPT), '--model', str(model_path),
                                     '--output', str(bad_output), '--repo-root', str(Path(directory) / 'wrong-root')],
                                    text=True, capture_output=True, check=False)
            self.assertEqual(result.returncode, 2)
            self.assertIn('Missing or escaping evidence file', result.stderr)
            self.assertNotIn('Traceback', result.stderr)
            self.assertFalse(bad_output.exists())


if __name__ == '__main__':
    unittest.main()
