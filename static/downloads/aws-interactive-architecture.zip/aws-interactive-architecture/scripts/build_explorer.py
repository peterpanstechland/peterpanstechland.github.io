#!/usr/bin/env python3
"""Validate an evidence model and build one self-contained architecture HTML file."""
import argparse
import base64
import hashlib
import html
import json
import math
import re
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

PACKAGE = Path(__file__).resolve().parents[1]
IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,79}$")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def text(value, label):
    require(isinstance(value, str) and bool(value.strip()), f"{label}: expected nonempty text")


def identifier(value, label):
    require(isinstance(value, str) and bool(IDENTIFIER.fullmatch(value)), f"{label}: invalid ID")


def rectangle(box, label):
    require(isinstance(box, dict), f"{label}: expected object")
    for key in ('x', 'y', 'w', 'h'):
        value = box.get(key)
        require(type(value) in (int, float) and math.isfinite(value), f"{label}.{key}: finite number required")
        require(value >= 0 if key in ('x', 'y') else value > 0, f"{label}.{key}: invalid size or coordinate")
    require(box['w'] >= 180 and box['h'] >= 150 if label.startswith('placement') else True,
            f"{label}: starter cards need at least 180 × 150 units")


def validate(model, repo_root=None):
    require(isinstance(model, dict), 'Model must be an object')
    for key in ('title', 'subtitle'):
        text(model.get(key), key)
    require(model.get('locale') in ('en', 'zh'), 'locale must be en or zh')
    if model.get('repoUrl'):
        url = urlparse(model['repoUrl'])
        require(url.scheme == 'https' and url.netloc and not url.query and not url.fragment
                and not url.username and not url.password, 'repoUrl must be a public HTTPS repository URL')
        require(isinstance(model.get('revision'), str) and re.fullmatch(r'[A-Za-z0-9._/-]+', model['revision']),
                'revision required with repoUrl')
    require(isinstance(model.get('nodes'), list) and model['nodes'], 'nodes must be nonempty')
    node_ids = set()
    for node in model['nodes']:
        require(isinstance(node, dict), 'node must be an object')
        identifier(node.get('id'), 'node.id')
        require(node['id'] not in node_ids, 'Duplicate node ID: ' + node['id'])
        node_ids.add(node['id'])
        for key in ('title', 'summary', 'responsibility', 'limits', 'boundary'):
            text(node.get(key), node['id'] + '.' + key)
        require(node.get('status') in ('proposed', 'implemented', 'configured', 'observed'), 'Invalid node status')
        evidence = node.get('evidence')
        require(isinstance(evidence, list), 'evidence must be an array')
        require(evidence or node['status'] == 'proposed', 'Implementation/configuration/observation needs evidence')
        for item in evidence:
            require(isinstance(item, dict), 'evidence item must be an object')
            raw = item.get('path')
            text(raw, 'evidence.path')
            path = PurePosixPath(raw)
            require(not path.is_absolute() and '..' not in path.parts and '\\' not in raw
                    and not raw.startswith('.') and ':' not in raw, 'Evidence must use safe repository-relative paths')
            text(item.get('claim'), 'evidence.claim')
            if 'line' in item:
                require(type(item['line']) is int and item['line'] > 0, 'evidence.line must be a positive integer')
            if repo_root:
                full = (repo_root / raw).resolve()
                require(full.is_relative_to(repo_root.resolve()) and full.is_file(), 'Missing or escaping evidence file: ' + raw)
                if 'line' in item:
                    require(item['line'] <= len(full.read_text(encoding='utf-8').splitlines()), 'Evidence line out of range: ' + raw)
        if 'icon' in node:
            identifier(node['icon'], 'node.icon')
    require(isinstance(model.get('folders'), list) and model['folders'], 'folders must be nonempty')
    folder_ids = set()
    for folder in model['folders']:
        require(isinstance(folder, dict), 'folder must be an object')
        identifier(folder.get('id'), 'folder.id')
        require(folder['id'] not in folder_ids, 'Duplicate folder ID')
        folder_ids.add(folder['id'])
        text(folder.get('title'), 'folder.title')
        text(folder.get('description'), 'folder.description')
        boxes = folder.get('nodes')
        require(isinstance(boxes, list) and boxes, 'Folder needs placements')
        placed = set()
        for box in boxes:
            require(isinstance(box, dict), 'placement must be an object')
            rectangle(box, 'placement ' + str(box.get('id')))
            require(box.get('id') in node_ids and box['id'] not in placed, 'Missing or duplicate placement')
            placed.add(box['id'])
        for i, a in enumerate(boxes):
            for b in boxes[i + 1:]:
                overlap = a['x'] < b['x'] + b['w'] and a['x'] + a['w'] > b['x'] and a['y'] < b['y'] + b['h'] and a['y'] + a['h'] > b['y']
                require(not overlap, 'Overlapping placements: ' + a['id'] + ', ' + b['id'])
        edges = folder.get('edges')
        require(isinstance(edges, list), 'edges must be an array')
        edge_ids = set()
        width = max(b['x'] + b['w'] for b in boxes)
        height = max(b['y'] + b['h'] for b in boxes)
        require(isinstance(folder.get('boundaries', []), list), 'boundaries must be an array')
        for boundary in folder.get('boundaries', []):
            rectangle(boundary, 'boundary')
            text(boundary.get('title'), 'boundary.title')
            require(boundary.get('kind') in ('aws', 'external'), 'Invalid boundary kind')
            width = max(width, boundary['x'] + boundary['w'])
            height = max(height, boundary['y'] + boundary['h'])
        for edge in edges:
            require(isinstance(edge, dict), 'edge must be an object')
            identifier(edge.get('id'), 'edge.id')
            require(edge['id'] not in edge_ids, 'Duplicate edge ID')
            edge_ids.add(edge['id'])
            require(edge.get('from') in placed and edge.get('to') in placed and edge['from'] != edge['to'], 'Missing edge endpoint or unsupported self-loop')
            text(edge.get('label'), 'edge.label')
            require(edge.get('kind') in ('sync', 'async', 'data', 'approval'), 'Invalid edge kind')
            for key in ('fromPort', 'toPort'):
                if key in edge:
                    require(edge[key] in ('top', 'bottom', 'left', 'right'), 'Invalid port')
            via = edge.get('via', [])
            require(isinstance(via, list), 'via must be an array')
            for p in via:
                require(isinstance(p, list) and len(p) == 2 and all(type(v) in (int, float) and math.isfinite(v) for v in p)
                        and 0 <= p[0] <= width + 36 and 0 <= p[1] <= height + 70, 'via point outside diagram')
        require(isinstance(folder.get('steps'), list), 'steps must be an array')
        for step in folder['steps']:
            require(isinstance(step, dict), 'step must be an object')
            require(step.get('edge') in edge_ids, 'Step references a missing edge')
            text(step.get('note'), 'step.note')
            require(step.get('branch') in ('main', 'alternative', 'failure', 'authoring'), 'Invalid step branch')
    return model


def build(model, icons_dir=None):
    model = json.loads(json.dumps(model))
    icons_dir = icons_dir or PACKAGE / 'assets/icons'
    manifest = json.loads((icons_dir / 'manifest.json').read_text(encoding='utf-8'))
    for node in model['nodes']:
        node.pop('iconData', None)  # Only verified package assets can become embedded icons.
        if node.get('icon'):
            name = node['icon']
            require(name in manifest['icons'], 'Icon missing from manifest: ' + name)
            data = (icons_dir / (name + '.svg')).read_bytes()
            require(hashlib.sha256(data).hexdigest() == manifest['icons'][name]['sha256'], 'Icon hash mismatch: ' + name)
            node['iconData'] = 'data:image/svg+xml;base64,' + base64.b64encode(data).decode('ascii')
    starter = PACKAGE / 'assets/starter'
    geometry = re.sub(r'^export (?=function )', '', (starter / 'geometry.mjs').read_text(encoding='utf-8'), flags=re.MULTILINE)
    values = {
        '__LOCALE__': model['locale'], '__TITLE__': html.escape(model['title']),
        '__STYLES__': (starter / 'styles.css').read_text(encoding='utf-8'),
        '__GEOMETRY__': geometry, '__EXPLORER__': (starter / 'explorer.mjs').read_text(encoding='utf-8'),
        '__MODEL__': json.dumps(model, ensure_ascii=False).replace('<', '\\u003c').replace('&', '\\u0026'),
    }
    template = (starter / 'index.html').read_text(encoding='utf-8')
    # One substitution pass: arbitrary model strings cannot become template directives.
    return re.sub('|'.join(map(re.escape, values)), lambda match: values[match.group()], template)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repo-root', type=Path)
    parser.add_argument('--icons', type=Path)
    args = parser.parse_args()
    try:
        model = validate(json.loads(args.model.read_text(encoding='utf-8')), args.repo_root)
        output = build(model, args.icons)
    except (ValueError, KeyError, TypeError, OSError) as error:
        parser.exit(2, f'Model/build error: {error}\n')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(output, encoding='utf-8')
    print(f'Built {args.output} ({len(output.encode())} bytes); no cloud calls.')


if __name__ == '__main__':
    main()
