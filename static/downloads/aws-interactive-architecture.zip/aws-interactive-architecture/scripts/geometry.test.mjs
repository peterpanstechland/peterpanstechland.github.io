import test from 'node:test';
import assert from 'node:assert/strict';
import { Worker } from 'node:worker_threads';
import { routeConnection, fitDiagram, wrapText } from '../assets/starter/geometry.mjs';

const bounds = { width: 360, height: 180 };
const boxes = [
  { id: 'a', x: 20, y: 20, w: 60, h: 40 },
  { id: 'b', x: 260, y: 20, w: 60, h: 40 },
];
const edge = { id: 'request', from: 'a', to: 'b' };

function assertSafe(points, cards = boxes, frame = bounds) {
  assert.ok(points.length >= 2);
  for (const [x, y] of points) {
    assert.ok(Number.isFinite(x) && Number.isFinite(y));
    assert.ok(x >= 0 && x <= frame.width && y >= 0 && y <= frame.height);
  }
  for (let i = 1; i < points.length; i++) {
    const [a, b] = [points[i - 1], points[i]];
    assert.notDeepEqual(a, b, 'no zero-length segments');
    assert.ok(a[0] === b[0] || a[1] === b[1], 'orthogonal segments');
    for (const card of cards) {
      const crosses = a[0] === b[0] ?
        a[0] > card.x && a[0] < card.x + card.w &&
          Math.max(a[1], b[1]) > card.y && Math.min(a[1], b[1]) < card.y + card.h :
        a[1] > card.y && a[1] < card.y + card.h &&
          Math.max(a[0], b[0]) > card.x && Math.min(a[0], b[0]) < card.x + card.w;
      assert.equal(crosses, false, `segment crosses ${card.id}`);
    }
  }
}

test('origin regression completes in a bounded worker instead of hanging on a negative grid index', async () => {
  const moduleUrl = new URL('../assets/starter/geometry.mjs', import.meta.url).href;
  const code = `const {parentPort,workerData}=require('node:worker_threads');
    import(workerData).then(({routeConnection}) => {
    const boxes = [{id:'a',x:0,y:0,w:50,h:50},{id:'b',x:150,y:0,w:50,h:50}];
    parentPort.postMessage(routeConnection({id:'origin',from:'a',to:'b'},boxes,{width:200,height:100}));
    });`;
  const worker = new Worker(code, { eval: true, workerData: moduleUrl });
  let timer;
  try {
    const points = await new Promise((resolve, reject) => {
      timer = setTimeout(() => reject(new Error('Origin routing exceeded 2 seconds')), 2000);
      worker.once('message', resolve); worker.once('error', reject);
      worker.once('exit', code => { if (code) reject(new Error(`Worker exited with ${code}`)); });
    });
    assert.deepEqual(points, [[50, 25], [150, 25]]);
  } finally { clearTimeout(timer); await worker.terminate(); }
});

test('routes around intervening cards and retains the directed endpoints', () => {
  const cards = [...boxes, { id: 'obstacle', x: 140, y: 0, w: 50, h: 90 }];
  const points = routeConnection(edge, cards, bounds);
  assertSafe(points, cards);
  assert.deepEqual(points[0], [80, 40]);
  assert.deepEqual(points.at(-1), [260, 40]);
  assert.ok(points.some(point => point[1] >= 96));
  assertSafe(routeConnection({ ...edge, from: 'b', to: 'a' }, cards, bounds), cards);
});

test('every explicit cardinal port controls both the endpoint and the first or last segment', () => {
  const cards = [{ id: 'a', x: 60, y: 60, w: 60, h: 60 },
    { id: 'b', x: 260, y: 180, w: 60, h: 60 }];
  const frame = { width: 400, height: 320 };
  const anchors = box => ({ left: [box.x, box.y + box.h / 2],
    right: [box.x + box.w, box.y + box.h / 2], top: [box.x + box.w / 2, box.y],
    bottom: [box.x + box.w / 2, box.y + box.h] });
  const outward = (anchor, next, port) => port === 'left' ? next[0] < anchor[0] :
    port === 'right' ? next[0] > anchor[0] : port === 'top' ? next[1] < anchor[1] : next[1] > anchor[1];
  for (const fromPort of ['top', 'bottom', 'left', 'right']) {
    for (const toPort of ['top', 'bottom', 'left', 'right']) {
      const points = routeConnection({ ...edge, fromPort, toPort }, cards, frame);
      assertSafe(points, cards, frame);
      assert.deepEqual(points[0], anchors(cards[0])[fromPort]);
      assert.deepEqual(points.at(-1), anchors(cards[1])[toPort]);
      assert.ok(outward(points[0], points[1], fromPort));
      assert.ok(outward(points.at(-1), points.at(-2), toPort));
    }
  }
});

test('via constraints are visited in order, including collinear waypoints', () => {
  const via = [[110, 140], [180, 140], [230, 140]];
  const points = routeConnection({ ...edge, via }, boxes, bounds);
  assertSafe(points);
  const indices = via.map(point => points.findIndex(candidate => candidate[0] === point[0] && candidate[1] === point[1]));
  assert.ok(indices[0] >= 0 && indices[1] > indices[0] && indices[2] > indices[1]);
});

test('parallel edge IDs are independent and do not collapse geometry', () => {
  const first = routeConnection({ ...edge, id: 'http', label: 'HTTP' }, boxes, bounds);
  const second = routeConnection({ ...edge, id: 'websocket', label: 'WSS' }, boxes, bounds);
  assertSafe(first); assertSafe(second);
  assert.deepEqual(first, second);
  assert.notEqual(first, second);
});

test('missing endpoints, duplicate IDs, overlapping cards and self-loops fail explicitly', () => {
  assert.throws(() => routeConnection({ ...edge, to: 'missing' }, boxes, bounds), /Missing endpoint/);
  assert.throws(() => routeConnection(edge, [boxes[0], { ...boxes[1], id: 'a' }], bounds), /unique/);
  assert.throws(() => routeConnection(edge, [boxes[0], { ...boxes[1], x: 50 }], bounds), /Overlapping/);
  assert.throws(() => routeConnection({ ...edge, to: 'a' }, boxes, bounds), /Self-loop.*unsupported/);
});

test('invalid, non-finite and out-of-bounds geometry fails before searching', () => {
  for (const change of [{ x: NaN }, { y: Infinity }, { x: -1 }, { w: 0 }, { h: -1 }, { x: 350 }]) {
    assert.throws(() => routeConnection(edge, [{ ...boxes[0], ...change }, boxes[1]], bounds), /geometry|bounds/);
  }
  for (const frame of [{ width: 0, height: 10 }, { width: 10, height: NaN }, { width: Infinity, height: 10 }]) {
    assert.throws(() => routeConnection(edge, boxes, frame), /finite positive/);
  }
});

test('invalid ports, blocked via points and ports outside layout padding fail explicitly', () => {
  assert.throws(() => routeConnection({ ...edge, fromPort: 'diagonal' }, boxes, bounds), /Unsupported port/);
  assert.throws(() => routeConnection({ ...edge, via: [[30, 30]] }, boxes, bounds), /blocked/);
  for (const via of [[[NaN, 100]], [[100, Infinity]], [[-1, 100]], [[100, 190]], 'unsupported', [[100]]]) {
    assert.throws(() => routeConnection({ ...edge, via }, boxes, bounds), /Via|via/);
  }
  assert.throws(() => routeConnection({ ...edge, fromPort: 'left' },
    [{ ...boxes[0], x: 0 }, boxes[1]], bounds), /padding/);
});

test('an obstacle spanning the viewport cannot be crossed along its boundary', () => {
  const cards = [...boxes, { id: 'wall', x: 140, y: 0, w: 40, h: 180 }];
  assert.throws(() => routeConnection(edge, cards, bounds), /No orthogonal route/);
});

test('fit contains wide and tall diagrams in both dimensions, without upscaling', () => {
  assert.deepEqual(fitDiagram({ width: 1000, height: 2000 }, { width: 1032, height: 1032 }),
    { scale: 0.5, width: 500, height: 1000 });
  assert.deepEqual(fitDiagram({ width: 2000, height: 1000 }, { width: 1032, height: 1032 }),
    { scale: 0.5, width: 1000, height: 500 });
  assert.equal(fitDiagram({ width: 100, height: 50 }, { width: 1000, height: 1000 }).scale, 1);
  for (const viewport of [{ width: 340, height: 560 }, { width: 1180, height: 600 }, { width: 1, height: 1 }]) {
    const result = fitDiagram({ width: 1368, height: 1560 }, viewport);
    assert.ok(result.scale > 0 && result.scale <= 1);
    assert.ok(result.width <= viewport.width && result.height <= viewport.height);
    assert.ok(Math.abs(result.width / result.height - 1368 / 1560) < 1e-10);
  }
});

test('fit rejects invalid dimensions and padding instead of producing NaN or Infinity', () => {
  const valid = { width: 100, height: 100 };
  for (const value of [0, -1, NaN, Infinity, undefined, '100']) {
    assert.throws(() => fitDiagram({ ...valid, width: value }, valid), /finite positive/);
    assert.throws(() => fitDiagram(valid, { ...valid, height: value }), /finite positive/);
  }
  for (const padding of [-1, Infinity, NaN]) assert.throws(() => fitDiagram(valid, valid, padding), /Padding/);
});

test('wrap handles normal words, long tokens, Chinese, whitespace and truncation', () => {
  assert.deepEqual(wrapText('Amazon API Gateway', 10, 3), ['Amazon API', 'Gateway']);
  assert.deepEqual(wrapText('abcdefghijk', 4, 4), ['abcd', 'efgh', 'ijk']);
  assert.deepEqual(wrapText('可点击服务职责与实现证据', 4, 3), ['可点击服', '务职责与', '实现证据']);
  assert.deepEqual(wrapText('abcdefghijklmnop', 4, 2), ['abcd', 'efg…']);
  assert.deepEqual(wrapText('  a\n b\t c  ', 4, 3), ['a b', 'c']);
  assert.deepEqual(wrapText('', 4, 3), []);
  assert.deepEqual(wrapText('ab', 1, 1), ['…']);
  assert.deepEqual(wrapText('😀😀😀', 2, 2), ['😀😀', '😀']);
  assert.throws(() => wrapText('text', 0), /positive integers/);
});
