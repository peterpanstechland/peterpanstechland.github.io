/** Dependency-free geometry for the offline architecture explorer. */
const CLEARANCE = 6;
const STUB = 12;
const PORTS = new Set(['top', 'bottom', 'left', 'right']);
const finite = value => typeof value === 'number' && Number.isFinite(value);
const positive = value => finite(value) && value > 0;
const samePoint = (a, b) => a[0] === b[0] && a[1] === b[1];

function dimensions(value, label) {
  if (!value || !positive(value.width) || !positive(value.height)) {
    throw new Error(`${label} width and height must be finite positive numbers`);
  }
}

/** Contain both dimensions without upscaling, including very small viewports. */
export function fitDiagram(diagram, viewport, padding = 16) {
  dimensions(diagram, 'Diagram');
  dimensions(viewport, 'Viewport');
  if (!finite(padding) || padding < 0) throw new Error('Padding must be finite and nonnegative');
  const inset = Math.min(padding, viewport.width / 4, viewport.height / 4);
  const scale = Math.min(1, (viewport.width - inset * 2) / diagram.width,
    (viewport.height - inset * 2) / diagram.height);
  if (!positive(scale)) throw new Error('Dimensions exceed the representable numeric range');
  return { scale, width: diagram.width * scale, height: diagram.height * scale };
}

/** Wrap Unicode characters, break long tokens, and mark text omitted by maxLines. */
export function wrapText(text, maxChars = 26, maxLines = 3) {
  if (typeof text !== 'string') throw new Error('Text must be a string');
  if (!Number.isInteger(maxChars) || maxChars < 1 || !Number.isInteger(maxLines) || maxLines < 1) {
    throw new Error('Text capacities must be positive integers');
  }
  const remaining = Array.from(text.trim().replace(/\s+/gu, ' '));
  const lines = [];
  while (remaining.length && lines.length < maxLines) {
    let count = Math.min(maxChars, remaining.length);
    if (remaining.length > maxChars) {
      const space = remaining.slice(0, maxChars + 1).lastIndexOf(' ');
      if (space > 0) count = space;
    }
    lines.push(remaining.splice(0, count).join('').trim());
    while (remaining[0] === ' ') remaining.shift();
  }
  if (remaining.length) lines[lines.length - 1] =
    Array.from(lines.at(-1)).slice(0, maxChars - 1).join('') + '…';
  return lines;
}

function validateBoxes(boxes, bounds) {
  dimensions(bounds, 'Bounds');
  if (!Array.isArray(boxes)) throw new Error('Boxes must be an array');
  const ids = new Set();
  for (const box of boxes) {
    if (!box || typeof box.id !== 'string' || !box.id || ids.has(box.id)) {
      throw new Error('Every box must have a unique nonempty ID');
    }
    ids.add(box.id);
    if (![box.x, box.y].every(value => finite(value) && value >= 0) ||
        !positive(box.w) || !positive(box.h) ||
        !finite(box.x + box.w) || !finite(box.y + box.h)) {
      throw new Error(`Invalid box geometry: ${box.id}`);
    }
    if (box.x + box.w > bounds.width || box.y + box.h > bounds.height) {
      throw new Error(`Box outside bounds: ${box.id}`);
    }
  }
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const a = boxes[i], b = boxes[j];
    if (a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y) {
      throw new Error(`Overlapping boxes: ${a.id}, ${b.id}`);
    }
  }
}

function defaultPort(a, b) {
  const dx = b.x + b.w / 2 - a.x - a.w / 2;
  const dy = b.y + b.h / 2 - a.y - a.h / 2;
  return Math.abs(dx) >= Math.abs(dy) ? (dx >= 0 ? 'right' : 'left') :
    (dy >= 0 ? 'bottom' : 'top');
}

function endpoint(box, port) {
  if (!PORTS.has(port)) throw new Error(`Unsupported port: ${port}`);
  const x = box.x + box.w / 2, y = box.y + box.h / 2;
  if (port === 'left') return [[box.x, y], [box.x - STUB, y]];
  if (port === 'right') return [[box.x + box.w, y], [box.x + box.w + STUB, y]];
  if (port === 'top') return [[x, box.y], [x, box.y - STUB]];
  return [[x, box.y + box.h], [x, box.y + box.h + STUB]];
}

/**
 * Route one directed edge through a finite orthogonal visibility grid.
 * Ports and via points are constraints; unavailable routes fail explicitly.
 * Edge IDs are deliberately not used to deduplicate parallel connections.
 */
export function routeConnection(edge, boxes, bounds) {
  validateBoxes(boxes, bounds);
  const from = boxes.find(box => box.id === edge?.from);
  const to = boxes.find(box => box.id === edge?.to);
  if (!from || !to) throw new Error(`Missing endpoint: ${edge?.from} → ${edge?.to}`);
  if (from === to) throw new Error('Self-loop routing is unsupported; model a separate relay node');
  const [start, startStub] = endpoint(from, edge.fromPort ?? defaultPort(from, to));
  const [end, endStub] = endpoint(to, edge.toPort ?? defaultPort(to, from));
  const via = edge.via ?? [];
  if (!Array.isArray(via)) throw new Error('Via points must be an array');
  const inBounds = point => Array.isArray(point) && point.length === 2 &&
    point.every(finite) && point[0] >= 0 && point[0] <= bounds.width &&
    point[1] >= 0 && point[1] <= bounds.height;
  if (![startStub, endStub, ...via].every(inBounds)) {
    throw new Error('Port stubs and via points must be finite and inside bounds; add layout padding');
  }
  const obstacles = boxes.map(box => ({ id: box.id,
    left: box.x - CLEARANCE, right: box.x + box.w + CLEARANCE,
    top: box.y - CLEARANCE, bottom: box.y + box.h + CLEARANCE }));
  const inside = point => obstacles.some(box => point[0] > box.left &&
    point[0] < box.right && point[1] > box.top && point[1] < box.bottom);
  const clear = (a, b, except) => !obstacles.some(box => box.id !== except &&
    (a[0] === b[0] ? a[0] > box.left && a[0] < box.right &&
      Math.max(a[1], b[1]) > box.top && Math.min(a[1], b[1]) < box.bottom :
      a[1] > box.top && a[1] < box.bottom &&
      Math.max(a[0], b[0]) > box.left && Math.min(a[0], b[0]) < box.right));
  const stops = [startStub, ...via, endStub];
  if (stops.some(inside) || !clear(start, startStub, from.id) || !clear(endStub, end, to.id)) {
    throw new Error('No route: a port or via point is blocked by a box');
  }
  const sorted = values => [...new Set(values)].sort((a, b) => a - b);
  const xs = sorted([0, bounds.width, ...stops.map(point => point[0]),
    ...obstacles.flatMap(box => [box.left, box.right])].filter(value => value >= 0 && value <= bounds.width));
  const ys = sorted([0, bounds.height, ...stops.map(point => point[1]),
    ...obstacles.flatMap(box => [box.top, box.bottom])].filter(value => value >= 0 && value <= bounds.height));
  const cellCount = xs.length * ys.length;
  if (cellCount > 200000) throw new Error('Routing grid too large; split this diagram into folders');
  const pointAt = id => [xs[id % xs.length], ys[Math.floor(id / xs.length)]];
  const idAt = point => {
    const x = xs.indexOf(point[0]), y = ys.indexOf(point[1]);
    if (x < 0 || y < 0) throw new Error('Routing endpoint missing from grid');
    return y * xs.length + x;
  };
  function leg(a, b) {
    const first = idAt(a), last = idAt(b);
    const distance = new Map([[first, 0]]), previous = new Map();
    const open = new Set([first]), closed = new Set();
    while (open.size && closed.size < cellCount) {
      let current, best = Infinity;
      for (const id of open) {
        const p = pointAt(id), score = distance.get(id) + Math.abs(p[0] - b[0]) + Math.abs(p[1] - b[1]);
        if (score < best) { best = score; current = id; }
      }
      if (current === undefined) break;
      if (current === last) {
        const result = [pointAt(last)];
        for (let id = last; id !== first;) { id = previous.get(id); result.unshift(pointAt(id)); }
        return result;
      }
      open.delete(current); closed.add(current);
      const x = current % xs.length, y = Math.floor(current / xs.length), p = pointAt(current);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, next = ny * xs.length + nx;
        if (nx < 0 || nx >= xs.length || ny < 0 || ny >= ys.length || closed.has(next)) continue;
        const q = pointAt(next);
        if (inside(q) || !clear(p, q)) continue;
        const cost = distance.get(current) + Math.abs(q[0] - p[0]) + Math.abs(q[1] - p[1]);
        if (cost < (distance.get(next) ?? Infinity)) {
          distance.set(next, cost); previous.set(next, current); open.add(next);
        }
      }
    }
    throw new Error(`No orthogonal route: ${edge.from} → ${edge.to}`);
  }
  const points = [start];
  for (let i = 1; i < stops.length; i++) points.push(...leg(stops[i - 1], stops[i]));
  points.push(end);
  const unique = points.filter((point, i) => i === 0 || !samePoint(point, points[i - 1]));
  return unique.filter((point, i) => i === 0 || i === unique.length - 1 ||
    via.some(stop => samePoint(stop, point)) ||
    !((unique[i - 1][0] === point[0] && point[0] === unique[i + 1][0]) ||
      (unique[i - 1][1] === point[1] && point[1] === unique[i + 1][1])));
}
