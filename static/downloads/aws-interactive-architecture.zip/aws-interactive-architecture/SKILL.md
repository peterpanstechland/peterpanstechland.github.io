---
name: aws-interactive-architecture
description: Create clickable AWS architecture diagrams from repository evidence, with workflow tabs, narrated path playback, complete-diagram fitting, and portable SVG export. Use for architecture explainers and solution walkthroughs; a diagram does not audit live infrastructure or authorize deployment.
---

# Interactive AWS architecture

Turn a solution into an explorable map whose arrows and service claims can be checked against implementation. Follow the user's destination and visual conventions. Prefer a small, static explorer over copying a product page that opens sessions or calls cloud APIs.

## Establish what the diagram can claim

Inspect the relevant infrastructure, handlers, configuration and tests. Trace at least one user action from entry to durable output. Distinguish code that is implemented, configuration that is declared, deployment that is independently verified, and behavior that was actually observed. A service name in a README is not evidence of an active request path.

Read [the evidence contract](references/evidence-contract.md) when building the model. For each consequential node or edge, record its responsibility, boundary, implementation evidence and operating limit. Leave missing information unknown. Keep deployment identifiers, access tokens and signed URLs out of the shareable artifact.

Use current AWS service names and official icon assets when available. Verify icon provenance; this package includes a pinned official icon subset and a source/hash manifest. Include only services used by the target solution. Keep third-party services, clients and build-time authoring tools outside the AWS boundary. Do not imply that using official icons certifies the architecture.

## Shape the explanation

Group tabs around user workflows, followed by independent operations or optional integrations. A walkthrough is a teaching sequence: label alternative, failure and authoring branches rather than implying every edge runs sequentially. Give each edge a stable unique ID, including parallel edges between the same nodes.

Node details should answer: what happens here, what supports that statement, what crosses the boundary, and what can fail. Prefer links pinned to a repository revision when sharing publicly. Treat logical grouping, Region, VPC and availability-zone topology as different claims.

## Build the explorer

The included starter works without a framework, build server, cloud account or external API. It provides keyboard-accessible folder tabs and nodes, step playback, reduced-motion handling, whole-map fitting, zoom, evidence links and self-contained SVG export.

Use [the model format](references/model-format.md) and the small neutral example at `assets/starter/example.json`. Place a model in the requested project, then build:

```bash
python /path/to/aws-interactive-architecture/scripts/build_explorer.py \
  --model architecture.json --output public/architecture.html \
  --repo-root /path/to/the/repository
```

Omit `--repo-root` for an explicitly illustrative model. It checks evidence file paths when supplied; it cannot establish that a cited line proves a claim. The output is one HTML file with embedded icons, CSS, geometry and model data, usable directly or inside an iframe. For an existing React site, adapt the model and pure geometry functions while retaining that site's navigation and styling.

Read [interaction and layout](references/interaction-and-layout.md) when adapting the starter or designing a larger map. Arrange dense flows explicitly or split them into tabs; obstacle routing does not promise optimal graph layout.

## Verify and deliver

Run the builder's model validation and the geometry regression tests:

```bash
node --test /path/to/aws-interactive-architecture/scripts/geometry.test.mjs
```

Inspect desktop and narrow-screen views. Check tab and node keyboard interaction, folder reset during playback, pause/resume and final-step stopping, fitting both dimensions, and the reduced-motion alternative. Confirm the explorer makes no cloud requests. Open an exported SVG on its own: icons must remain present and playback highlights must be absent. Sample evidence links and verify the actual claims, not merely that files exist.

Deliver the diagram, editable model and relevant evidence gaps. Preserve the user's hosting and publication choices; creating the artifact does not by itself authorize infrastructure changes or external publication.
