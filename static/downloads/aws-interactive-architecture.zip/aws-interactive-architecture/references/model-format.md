# Model format

`assets/starter/example.json` is a complete neutral example. Its nodes are proposed, not evidence of a deployed AWS workload.

Top-level fields:

- `title`, `subtitle`: readable text; `locale` is `en` or `zh`.
- `repoUrl`: optional public HTTPS repository URL without query parameters; `revision`: optional immutable commit preferred for shared evidence.
- `nodes`: unique `id`, `title`, `summary`, `responsibility`, `limits`, `boundary`, `status`, optional `icon`, and `evidence` entries (`path`, optional `line`, `claim`). `boundary` is a descriptive string; the surrounding rectangles are declared per folder.
- `folders`: unique `id`, `title`, `description`, `nodes` placements, `edges`, `steps`, and optional `boundaries`.

A placement has `id`, `x`, `y`, `w`, `h`. Coordinates are nonnegative and finite; dimensions are positive. The included card renderer requires `w >= 180` and `h >= 150`. Each folder includes only nodes needed for that explanation.

An edge has a unique `id`, `from`, `to`, `label`, and `kind`: `sync`, `async`, `data` or `approval`. Optional `fromPort`/`toPort` select `top`, `bottom`, `left` or `right`; optional `via` is an ordered list of `[x,y]` orthogonal-routing waypoints. Endpoints must be placed in the same folder. Parallel endpoint pairs keep distinct edge IDs.

A walkthrough step has `edge`, `note`, and `branch`: `main`, `alternative`, `failure`, or `authoring`. The step's edge must exist. An empty walkthrough is valid. Steps illustrate responsibilities and teaching order; they do not execute services.

A boundary has `title`, `x`, `y`, `w`, `h`, and `kind` (`aws` or `external`). AWS rectangles are logical groups unless the model explicitly establishes topology. Do not infer node membership from a service name or draw build tools into a request path.

Icons refer to filenames without `.svg` in `assets/icons/`. The builder verifies each used SVG against its manifest and embeds it in the output. With `--icons`, provide another directory containing SVGs and a matching manifest; this is preferable to expanding the package with unused services.

The builder checks structure and source-file references. It does not call AWS, discover resources, assess service availability, validate basketball facts, or prove the semantic accuracy of an arrow.
