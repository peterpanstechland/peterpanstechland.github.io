# Interaction and layout contracts

**Fit means contain both width and height.** Measure the actual diagram viewport, account for padding, and recompute on container resize and tab changes. Fit mode must not pan toward a highlighted node and crop the remaining map. At percentage zoom, pan only the map container; never scroll the whole article or move keyboard focus.

**Playback references edge IDs.** Endpoint pairs are insufficient when two protocols share the same nodes. Reset playback when changing folders. Clicking a node pauses the walkthrough and exposes its details. Keep manual previous/next and step selection available when reduced motion disables timed playback. The last step stops instead of silently restarting.

**Text belongs in two layers.** Use concise titles and summaries inside cards, with complete responsibilities and limits in the detail panel. Wrap CJK text and long unbroken English tokens. Clipping a detailed card is not a substitute for readable detail text. A full diagram will necessarily shrink on a phone; provide zoom and accessible node details.

**Geometry must terminate.** Validate finite coordinates, positive card dimensions, known endpoints, and non-overlapping boxes before routing. Include endpoint coordinates in the visibility grid, even at the origin. Bound the search and report a routing failure. Honor explicit ports and waypoints or reject them clearly. The starter rejects self-loops; represent such behavior in node detail or add and test a deliberate self-loop renderer.

**SVG exports are generated from neutral state.** Re-render with no selected node, active edge or moving dash, and embed the official icon bytes. Do not clone a live highlighted diagram and assume removing animation removes all selection styling. The exported caption should identify its logical scope and source revision.

The starter's router avoids node rectangles; it does not solve edge crossings, semantic grouping, or optimal label placement. Edges use numbered markers and a separate readable path list. Split dense workflows rather than promising perfect auto-layout.
