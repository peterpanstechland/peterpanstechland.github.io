# Evidence and architecture claims

A diagram describes an asserted scope. Name that scope rather than letting a cloud outline imply more than the evidence establishes.

- **Proposed:** a design suggestion. Do not give it an implementation badge.
- **Implemented:** handlers or infrastructure code express the behavior. Link the relevant symbol or file at a revision.
- **Configured:** a setting or resource declaration exists. This alone does not prove deployment or successful execution.
- **Observed:** an identifiable check demonstrated the stated behavior. Describe what was checked and the limits of the observation. Do not publish private run records or claim an accuracy benchmark from a successful API call.

The starter intentionally has no automatic "deployed" badge. If a target needs one, add the verification evidence and its scope explicitly.

For an evidence entry, use a repository-relative `path`, optional positive `line`, and a `claim` explaining what the reference supports. With a public `repoUrl` and pinned `revision`, the explorer links directly to that source. Filesystem existence is validated when the builder receives `--repo-root`; semantic support remains a review task.

## Questions that change the map

- Are bytes sent through an API, or does the API only register a direct-to-object-storage upload?
- Is a queue in the normal request path, a failure destination, or an independently consumed backlog?
- Which actor invokes the model, and which actor merely hosts the agent?
- Does an event carry the identity needed to route a notification?
- Which output is private advice, and what explicit action publishes it?
- Is a third-party tool called at runtime, optionally invoked by the user, or used only to author an asset?
- Does a Region label apply to application resources, model profiles, global edge services, or all of them?
- Are media files public, authorized, or served by expiring signed links?
- Is the diagram a logical grouping, or is subnet and availability-zone placement actually supported by infrastructure?

For the Courtside IQ case, Strands is the SDK, AgentCore Runtime hosts the agent, and Bedrock performs model inference. Its SQS destination stores unhandled worker failures; it is not the normal job queue or an automatic replay consumer. Its GLB assets were authored using Tripo separately from runtime video analysis. Those are examples to investigate in a new repository, not default architecture assumptions.
