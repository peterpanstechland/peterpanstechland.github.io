RoboPlanter Device Kit
Python 3.10+, standard library only.
Run: python3 integrations/device-kit/device_kit.py validate integrations/device-kit/profiles/*.json
Run tests: python3 -m unittest discover -s tests -p test_device_kit.py -v
This is an offline toolkit. No device connection, credential loading, or commands are supported.
Docs: https://peterpanstechland.github.io/docs/projects/2026/roboplanter/device-platform
