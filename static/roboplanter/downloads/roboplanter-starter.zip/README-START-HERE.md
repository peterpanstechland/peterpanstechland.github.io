# RoboPlanter public source reproduction kit

Start with docs/handbook/hardware-quickstart.md.
Public tutorial: https://peterpanstechland.github.io/docs/projects/2026/roboplanter/

This archive contains allowlisted source, example configuration, host tests and
documentation. It contains NO compiled firmware, device backup, credentials,
original vendor attachment, personal photos or platform account screenshots.
All actuators remain disabled by default. Reading this kit is not evidence that
YOYO BLE, your board or an attached pump has passed hardware validation.

Extract into an empty directory. Verify SOURCE-MANIFEST.json file hashes before
use. Copy only example configuration and create your own private credentials.
Start with offline tests and a disconnected bench load, following the tutorial.

Third-party notices remain in firmware/indicator/assets/fonts/OFL.txt and
firmware/indicator/third_party/esp-idf-LICENSE. This source availability does not
introduce a project-wide open-source licence; contact the maintainer regarding
reuse beyond project reproduction. Existing third-party licences still apply.
