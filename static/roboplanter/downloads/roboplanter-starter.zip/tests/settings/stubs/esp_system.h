#pragma once
#include <cstdint>
inline uint32_t esp_random() { return 0x12345678; }
